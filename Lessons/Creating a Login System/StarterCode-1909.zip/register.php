<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register Page</title>
</head>
<body>
    <form action="scripts/regScript.php" method="post">
        <input type="email" name="sEnteredEmail" id="sEnteredEmail">
        <input type="password" name="sEnteredPass" id="sEnteredPass">

        <button type="submit">Submit Form</button>
    </form>

    <a href="index.php">Go to Login Page</a>
</body>
</html>