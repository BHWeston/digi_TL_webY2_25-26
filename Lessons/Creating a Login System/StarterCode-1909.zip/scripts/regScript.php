<?php 
// Task - Get the posted variables from the previous page, output these onto the screen to test them:
$sSentUser = $_POST['sEnteredEmail'];
$sSentPass = $_POST['sEnteredPass'];

echo("This is the username $sSentUser");
echo("This is the password $sSentPass");
?>